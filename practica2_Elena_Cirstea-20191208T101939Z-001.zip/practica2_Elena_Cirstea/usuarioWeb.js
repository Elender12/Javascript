//clase de la cual va a heredar el resto
class UsuarioWeb{
    constructor(username, password, nombre, dni){
        this.username = username;
        this.password=password;
        this.nombre= nombre;
        this.dni= dni;  
}
}

class UsuarioGestor extends UsuarioWeb{
    constructor(username, password, nombre, dni){
    super(username,password,nombre,dni);
    this.rol = "gestor";
 
    }
}
class UsuarioCliente extends UsuarioWeb{
    constructor(username, password, nombre, dni, pesoInicial, altura, edad, sexo, imcInicial, FCMInicial){
        //datos que le paso al constructor
        super(username, password, nombre, dni);
        //datos propios de la clase
        this.rol = "cliente";
        this.pesoInicial = pesoInicial; //esta var necesita un historial
        this.altura= altura;
        this.edad=edad;
        this.sexo= sexo;
        this.imcInicial= imcInicial;
        this.FCMInicial = FCMInicial; //esta var necesita un historial
    }
}

   //Gestor->esta clase deberá dar de alta los empleados
    //Gestor ->crear las tablas de horario
    
